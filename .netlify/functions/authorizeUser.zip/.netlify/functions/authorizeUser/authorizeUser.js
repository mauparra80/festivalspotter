var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// .netlify/functions/authorizeUser/authorizeUser.js
var authorizeUser_exports = {};
__export(authorizeUser_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(authorizeUser_exports);
var import_crypto = __toESM(require("crypto"), 1);
var handler = async function(event, context) {
  console.log("Authorize user function called");
  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const redirectUri = `${process.env.URL}/callback`;
  const verifier = generateCodeVerifier(128);
  const challenge = await generateCodeChallenge(verifier);
  console.log("Redirect URI:", redirectUri);
  console.log("Verifier:", verifier);
  console.log("Challenge:", challenge);
  const params = new URLSearchParams();
  params.append("client_id", clientId);
  params.append("response_type", "code");
  params.append("redirect_uri", redirectUri);
  params.append("scope", "user-library-read playlist-read-private playlist-read-collaborative");
  params.append("code_challenge_method", "S256");
  params.append("code_challenge", challenge);
  const redirectUrl = `https://accounts.spotify.com/authorize?${params.toString()}&verifier=${verifier}`;
  console.log("Redirect URL:", redirectUrl);
  return {
    statusCode: 200,
    body: JSON.stringify({
      redirectUrl,
      verifier
    })
  };
};
function generateCodeVerifier(length) {
  let text = "";
  const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (let i = 0; i < length; i++) {
    text += possible.charAt(Math.floor(Math.random() * possible.length));
  }
  return text;
}
async function generateCodeChallenge(codeVerifier) {
  return new Promise((resolve, reject) => {
    const hash = import_crypto.default.createHash("sha256");
    hash.update(codeVerifier);
    const digest = hash.digest("base64");
    resolve(
      digest.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
    );
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
