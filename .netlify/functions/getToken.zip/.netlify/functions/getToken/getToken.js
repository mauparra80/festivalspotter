var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var getToken_exports = {};
__export(getToken_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(getToken_exports);
var import_node_fetch = __toESM(require("node-fetch"), 1);
const handler = async function(event, context) {
  console.log("this is the event passed into getTokensAPI", event);
  const code = new URLSearchParams(event.queryStringParameters).get("code");
  const verifier = new URLSearchParams(event.queryStringParameters).get("verifier");
  const redirect_Uri = `${process.env.URL}/callback`;
  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const tokenUrl = "https://accounts.spotify.com/api/token";
  const params = new URLSearchParams();
  params.append("grant_type", "authorization_code");
  params.append("code", code);
  params.append("redirect_uri", redirect_Uri);
  params.append("code_verifier", verifier);
  params.append("client_id", clientId);
  const headers = {
    "Content-Type": "application/x-www-form-urlencoded"
  };
  try {
    const response = await (0, import_node_fetch.default)(tokenUrl, {
      method: "POST",
      headers,
      body: params.toString()
    });
    if (!response.ok) {
      throw new Error("HTTP error! status: ", response.status);
    }
    const data = await response.json();
    if (data.error) {
      throw new Error(`API error: ${data.error} - ${data.error_description}`);
    }
    return {
      statusCode: 200,
      body: JSON.stringify({
        access_token: data.access_token,
        refresh_token: data.refresh_token
      })
    };
  } catch (error) {
    console.error("Error exchanging code for token: ", error.message);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to exchanged code for oken", details: error.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
