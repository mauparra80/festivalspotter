var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var generateWordCloud_exports = {};
__export(generateWordCloud_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generateWordCloud_exports);
var import_axios = __toESM(require("axios"), 1);
const handler = async function(event, handler2) {
  const options = {
    method: "POST",
    url: "https://textvis-word-cloud-v1.p.rapidapi.com/v1/textToCloud",
    headers: {
      "content-type": "application/json",
      "X-RapidAPI-Key": "86135b698cmshe47473a63834e96p1154f9jsn10a9a5a62584",
      "X-RapidAPI-Host": "textvis-word-cloud-v1.p.rapidapi.com"
    },
    data: {
      text: "This is a test. I repeat, this is a test. We are only testing the functionality of this api, nothing else. End of test.",
      scale: 0.5,
      width: 400,
      height: 400,
      colors: [
        "#375E97",
        "#FB6542",
        "#FFBB00",
        "#3F681C"
      ],
      font: "Tahoma",
      use_stopwords: true,
      language: "en",
      uppercase: false
    }
  };
  try {
    const response = await import_axios.default.request(options);
    console.log(response.data);
    return {
      statusCode: 200,
      body: response.data
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to fetch data from JamBase API" })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
